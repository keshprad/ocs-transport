#!/usr/bin/python3 -I
"""Install the pinned four-Spark memfd worker profile on spark-03."""
import fcntl
import grp
import hashlib
import os
from pathlib import Path
import pwd
import socket
import stat
import subprocess
import tempfile

PACKAGE = Path(__file__).resolve().parent
MANIFEST_HASH = '6787373f903af56cc303aa6b4a73a5959a636c9856491f4b7eb948f6b9cb0999'
RULE = Path('/etc/sudoers.d/ocs-roce-ring4-memfd')
USER = 'ocs-roce-native'

def run(*args):
    return subprocess.check_output(args, text=True).strip()

def safe_dir(directory):
    if directory == directory.parent:
        return
    safe_dir(directory.parent)
    directory.mkdir(mode=0o755, exist_ok=True)
    st = directory.lstat()
    if not stat.S_ISDIR(st.st_mode) or st.st_uid != 0 or st.st_mode & 0o022:
        raise ValueError(f'Unsafe destination directory {directory}')

def install():
    if os.geteuid() != 0 or socket.gethostname().split('.')[0] != 'spark-016e':
        raise SystemExit('Run this installer as root on spark-03.')
    if run('systemctl','list-units','--state=active,activating,deactivating','--no-pager','--no-legend','--plain','ocs-roce*.service','ocs-mrc*.service'):
        raise SystemExit('A benchmark service is active on spark-03.')
    manifest = (PACKAGE / 'SHA256SUMS').read_bytes()
    if hashlib.sha256(manifest).hexdigest() != MANIFEST_HASH:
        raise ValueError('Unexpected package manifest')
    files = {}
    for line in manifest.decode().splitlines():
        digest, relative = line.split('  ', 1)
        data = (PACKAGE / 'tree' / relative).read_bytes()
        if hashlib.sha256(data).hexdigest() != digest:
            raise ValueError(f'Checksum mismatch for {relative}')
        path = Path('/') / relative
        mode = 0o440 if path == RULE else 0o644 if path.suffix == '.service' else 0o755
        files[path] = (data, mode)
    prior_versions = {'/usr/local/libexec/ocs-roce-ring4-mode-hook': ['ad0764aa4f62fa58729b094b809857e37b6eb4e6254da4c42ad0beb8cc7114fe', '391e2a05be12957180715a0fb3a3494797b037350d17e27b6b9e338f0089e65f'], '/etc/systemd/system/ocs-roce-ring-two-way-pool.service': ['79c992e3a66bb8e39941f7abf5c3bf2d5afb59c89224a44456a67cb92ada9a8f']}
    upgrades = set()
    for path, (data, mode) in files.items():
        safe_dir(path.parent)
        if path.exists() or path.is_symlink():
            st = path.lstat()
            if (str(path) in prior_versions and stat.S_ISREG(st.st_mode) and st.st_uid == 0 and st.st_gid == 0 and stat.S_IMODE(st.st_mode) == mode and hashlib.sha256(path.read_bytes()).hexdigest() in prior_versions[str(path)]):
                upgrades.add(path)
                continue
            if (not stat.S_ISREG(st.st_mode) or st.st_uid != 0 or st.st_gid != 0 or
                    stat.S_IMODE(st.st_mode) != mode or path.read_bytes() != data):
                raise ValueError(f'Existing installation differs at {path}')
    try:
        grp.getgrnam(USER)
    except KeyError:
        run('groupadd','--system',USER)
    group = grp.getgrnam(USER)
    if group.gr_gid == 0 or group.gr_mem:
        raise ValueError('Unexpected benchmark group')
    try:
        account = pwd.getpwnam(USER)
    except KeyError:
        run('useradd','--system','--gid',USER,'--home-dir','/nonexistent','--no-create-home','--shell','/usr/sbin/nologin',USER)
        account = pwd.getpwnam(USER)
    if (account.pw_uid == 0 or account.pw_gid != group.gr_gid or account.pw_shell != '/usr/sbin/nologin'
            or account.pw_dir != '/nonexistent' or run('id','-G',USER) != str(group.gr_gid)
            or run('passwd','-S',USER).split()[1] != 'L'):
        raise ValueError('Unexpected benchmark account')
    units = [str(p) for p in files if p.suffix == '.service']
    created = []
    try:
        for path in [*(p for p in files if p != RULE), RULE]:
            if path == RULE:
                run('systemd-analyze','verify','--man=no','--generators=no','--recursive-errors=no',*units)
                run('systemctl','daemon-reload')
            if path in upgrades:
                with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.ocs-update-', delete=False) as tmp:
                    tmp.write(files[path][0])
                    tmp.flush()
                    os.fchmod(tmp.fileno(), files[path][1])
                os.replace(tmp.name, path)
            if path.exists():
                continue
            data, mode = files[path]
            with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.ocs-install-') as tmp:
                tmp.write(data)
                tmp.flush()
                os.fchmod(tmp.fileno(), mode)
                if path == RULE:
                    run('visudo','-cf',tmp.name)
                os.link(tmp.name,path)
                created.append(path)
        run('visudo','-cf',str(RULE))
    except BaseException:
        for path in reversed(created):
            path.unlink()
        run('systemctl','daemon-reload')
        raise
    print('Installed the persistent four-Spark memfd profile. The data ports stay in DPDK mode between runs.')

if __name__ == '__main__':
    os.environ['PATH'] = '/usr/sbin:/usr/bin:/sbin:/bin'
    if os.geteuid() != 0:
        raise SystemExit('Use sudo to install the spark-03 service profile.')
    with open('/run/ocs-ring4-install.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        install()
