#!/bin/bash
set -euo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
[[ $EUID == 0 && $(hostname -s) == spark-7e64 ]]
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
active=$(systemctl list-units --state=running,activating,deactivating --no-legend --plain 'ocs-roce*.service' 'ocs-mrc*.service')
[[ -z $active ]] || { echo 'Wait for the current benchmark to finish.' >&2; exit 1; }
[[ -x /opt/ocs-roce-app-bw/8c5058a-aggregate/roce_write ]] && id ocs-roce-native >/dev/null
stage=$(mktemp -d /run/ocs-roce-jumbo-install.XXXXXXXX)
trap 'rm -rf -- "$stage"' EXIT
units=(ocs-roce-bw-same-cable-jumbo-pool.service ocs-roce-bw-app-same-cable-jumbo-1.service ocs-roce-bw-app-same-cable-jumbo-2.service)
for file in "${units[@]}" pool.sh jumbo.sudoers SHA256SUMS; do
    install -o root -g root -m 0644 -- "$file" "$stage/$file"
done
printf '%s  %s\n' '7a787d3f1e96f3e0c858fe3db19782a2a43a285d8bd1a0bb97b838fe7307a9d9' "$stage/SHA256SUMS" | sha256sum --check --strict --status
(cd "$stage" && sha256sum --check --strict SHA256SUMS)
visudo -cf "$stage/jumbo.sudoers"
systemd-analyze verify --man=no --generators=no --recursive-errors=no "${units[@]/#/$stage/}"
install -D -o root -g root -m 0755 -- "$stage/pool.sh" /usr/local/libexec/ocs-roce-same-cable-jumbo-pool
for unit in "${units[@]}"; do
    install -o root -g root -m 0644 -- "$stage/$unit" "/etc/systemd/system/$unit"
done
systemctl daemon-reload
install -o root -g root -m 0440 -- "$stage/jumbo.sudoers" /etc/sudoers.d/ocs-roce-bw-same-cable-jumbo
echo 'spark-04 same-cable jumbo benchmark installed.'
