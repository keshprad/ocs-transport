"""Re-run the three forward edges with the original shared-PCIe scatter/gather units."""
import sys
sys.path.insert(0, "/tmp/ocs-roce-ring-gather.6oLbB5vU")
import gather

ring = gather.ring
ring.EDGES = tuple(pair for pair in ring.EDGES if not pair[0].reverse)
ring.SENDERS, ring.RECEIVERS = tuple(zip(*ring.EDGES))
ring.ENDPOINTS = tuple(e for pair in ring.EDGES for e in pair)
assert len(ring.EDGES) == 3 and all(e.pci.startswith("0000:") for e in ring.ENDPOINTS)
gather.base.run(3)
