#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
sudo -n /usr/bin/python3 -I ./bundle/install.py
