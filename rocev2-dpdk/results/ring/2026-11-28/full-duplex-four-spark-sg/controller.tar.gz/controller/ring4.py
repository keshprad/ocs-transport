#!/usr/bin/env python3
"""Run the published memfd gather profile on four full-duplex QSFP links from spark-04."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager, ExitStack
from pathlib import Path
import argparse
import hashlib
import os
import re
import socket
import statistics
import subprocess
import sys
import tempfile
import check_spark_peer_ring as peer
from check_spark_peer_ring import bw, ring, Endpoint, Pool

HOSTS = ('spark-04', 'spark-01', 'spark-02', 'spark-03')
def edges():
    old_forward, f2, f1, old_reverse, r1, r4 = peer.edges()
    ftx = Endpoint('spark-03', 'tx', 29403, '198.18.94.2')
    frx = Endpoint('spark-03', 'rx', 29404, '198.18.94.1')
    rtx = Endpoint('spark-03', 'tx', 29413, '198.18.94.4', True)
    rrx = Endpoint('spark-03', 'rx', 29414, '198.18.94.3', True)
    # Service "reverse-tx" uses the right QSFP, forward in the user's ring.
    paths = [r1,(old_reverse[0], rrx),(rtx, old_reverse[1]),r4,
             f2,(ftx,old_forward[1]),(old_forward[0],frx),f1]
    expected = [(1,2),(2,3),(3,4),(4,1),(2,1),(3,2),(4,3),(1,4)]
    assert [(int(a.host[-2:]),int(b.host[-2:])) for a,b in paths] == expected
    assert len({e for pair in paths for e in pair}) == 16
    return paths

@contextmanager
def tunnels(commands, sockets, paths):
    ctrl=HOSTS[0]
    sessions={h:[] for h in HOSTS[1:]}
    for i,(tx,rx) in enumerate(paths):
        hub = tx.port if tx.host == ctrl else rx.port if rx.host == ctrl else 32680+i
        if rx.host != ctrl:
            sessions[rx.host] += ['-L',f'127.0.0.1:{hub}:127.0.0.1:{rx.port}']
        if tx.host != ctrl:
            sessions[tx.host] += ['-R',f'127.0.0.1:{tx.port}:127.0.0.1:{hub}']
    with ExitStack() as stack:
        for host,options in sessions.items():
            control=str(Path(sockets)/(host+'.tunnel'))
            ssh=['ssh','-S',control,'-o','BatchMode=yes']
            subprocess.run([*ssh,'-fNT','-o','ConnectTimeout=6','-o','ControlMaster=yes','-o','ExitOnForwardFailure=yes','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=2',*options,host],check=True,timeout=12)
            stack.callback(subprocess.run,[*ssh,'-O','exit',host],check=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=6)
        for tx,_ in paths:
            bw.verify_loopback_listener(commands,tx.host,tx.port)
        yield

def preflight(commands, paths):
    def check_host(host):
        bw.require_idle(commands,host)
        peer.verify_idle(commands,host)
        bw.verify_service_access(commands, Pool(host))
        actual=commands.run(host,'sha256sum',peer.RELEASE/'roce_write').split()[0]
        bw.require(actual=='bcb390549d7d69a0a04f829eb3a28b74d6f228963601f50db7b40aa898e42c5b',f'{host}: worker mismatch')
        actual=commands.run(host,'sha256sum',peer.RELEASE/'roce_app_write').split()[0]
        bw.require(actual=='ac24500cbf6bedecf3e83d62fc0db1889a463eedd54d4e2ddd87c97753cd5e78',f'{host}: application mismatch')
        for e in (e for pair in paths for e in pair if e.host==host):
            if getattr(e,'direct_receiver',False):
                e.preflight(commands)
                continue
            ring.verify_unit(commands,e,peer.RELEASE,build_argv=peer.unit_argv)
            props=commands.properties(e,'Environment','BindsTo','After')
            bw.require(f'ROCE_RING_APP_CPU={peer.APP_CPUS[e.name]}' in props['Environment'].split() and
                       peer.POOL in props['BindsTo'].split() and peer.POOL in props['After'].split(),f'{e.label}: service configuration mismatch')
            if host != 'spark-03':
                ring.verify_link(commands,e)
        print(host,'preflight OK',flush=True)
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(check_host, HOSTS))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('output',type=Path)
    parser.add_argument('--samples',type=int,default=3)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    assert args.samples>0 and socket.gethostname().split('.')[0]=='spark-7e64'
    paths=edges()
    ring.HOSTS=HOSTS
    with tempfile.TemporaryDirectory(prefix='ring4-ctrl-') as sockets:
        commands=bw.Commands(sockets)
        preflight(commands,paths)
        with ExitStack() as stack:
            stack.enter_context(tunnels(commands,sockets,paths))
            if args.check: return
            output=args.output
            output.mkdir(exist_ok=False,parents=True)
            report={'mode':'DPDK memfd scatter/gather','ethernet_mtu':4200,'roce_pmtu':4096,'bytes_per_edge':ring.PAYLOAD,'forward':[ring.edge_name(*p) for p in paths[:4]],'trials':[]}
            bw.save_report(output,report)
            for host in HOSTS:
                pool=Pool(host)
                ident=bw.start(commands,pool,timeout=165)
                stack.callback(peer.verify_idle,commands,host)
                stack.callback(bw.stop_owned,commands,pool,ident)
                bw.require(peer.page_counts(commands,host)==[256,256,0,0],f'{host}: hugepage count mismatch')
                print(host,'jumbo pool ready',flush=True)
            for tx,rx in paths:
                for e in (tx,rx):
                    bw.require(ring.verify_link(commands,e)['ethernet_mtu']==4200,f'{e.label}: MTU mismatch')
            for trial in range(1,args.samples+3):
                print(f'Starting trial {trial}',flush=True)
                try:
                    result=peer.run_sample(commands,output,trial,paths)
                except bw.CycleError as error:
                    report.setdefault('incomplete_trials',[]).append({'attempt':trial,'error':str(error)})
                    bw.save_report(output,report)
                    retryable=any(re.search(r'WRITE failed after [0-9]+ retries', p.read_text()) for p in output.glob(f'{trial}-*.txt'))
                    if not retryable: raise
                    print('Transport retry limit exceeded; retained incomplete attempt',trial,flush=True)
                    continue
                result['attempt']=trial
                report['trials'].append(result)
                for i,label in enumerate(('lower','upper')):
                    report['median_ring_payload_gbps_'+label]=statistics.median(t['aggregate_payload_gbps_bounds'][i] for t in report['trials'])
                bw.save_report(output,report)
                print('Trial',trial,result['aggregate_payload_gbps_bounds'],'Gb/s;',result['verified_payload_bytes'],'verified bytes',flush=True)
                if len(report['trials']) == args.samples: break
            bw.require(len(report['trials']) == args.samples, 'Incomplete trial set')
if __name__=='__main__':
    main()
