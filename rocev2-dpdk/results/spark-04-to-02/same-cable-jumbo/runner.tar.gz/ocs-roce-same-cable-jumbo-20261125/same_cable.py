#!/usr/bin/env python3
"""Measure simultaneous DPDK WRITE with 4 KiB RoCE payloads on two PCIe functions sharing one QSFP cable."""

import argparse
from contextlib import ExitStack
from dataclasses import dataclass, replace
from pathlib import Path
import re
import shlex
import socket
import statistics
import subprocess
import sys
import tempfile
import time


import check_spark_bandwidth as bw
import stage_spark_app_bandwidth as stage

OUTPUT = Path(__file__).resolve().parent
LEFT = "app-same-cable-jumbo-1"
RIGHT = "app-same-cable-jumbo-2"
MODES = (LEFT, RIGHT)
POOL_UNIT = "ocs-roce-bw-same-cable-jumbo-pool.service"
POOL_HELPER = Path("/usr/local/libexec/ocs-roce-same-cable-jumbo-pool")
BACKING = "/dev/hugepages/ocs-roce-same-cable-jumbo"
SYSFS_POOL = Path("/sys/kernel/mm/hugepages/hugepages-2048kB")
LOCAL, REMOTE = "spark-04", "spark-02"
HOSTS = (LOCAL, REMOTE)
DESTINATION = Path("/opt/ocs-roce-app-bw/8c5058a-aggregate")
for name, rail in zip(MODES, (1, 2)):
    profile = bw.ALL_PROFILES[f"app-aggregate-{rail}"]
    bw.ALL_PROFILES[name] = replace(profile, port=29039 + rail, hugepages=True,
                                    pmtu=4096, ethernet_mtu=4200)
TX_LEFT, TX_RIGHT = (bw.Endpoint("tx", name) for name in MODES)
RX_LEFT, RX_RIGHT = (bw.Endpoint("rx", name) for name in MODES)
PAIRS = {LEFT: (TX_LEFT, RX_LEFT), RIGHT: (TX_RIGHT, RX_RIGHT)}
NEW = (TX_LEFT, TX_RIGHT, RX_LEFT, RX_RIGHT)


@dataclass(frozen=True)
class Pool:
    host: str
    unit: str = POOL_UNIT

    @property
    def label(self):
        return f"{self.host} {self.unit}"


def jumbo_argv(endpoint):
    argv = bw.unit_argv(endpoint, DESTINATION, DESTINATION / "lib")
    directory = f"{BACKING}/{endpoint.settings.rail}"
    return [f"--huge-dir={directory}" if arg.startswith("--huge-dir=") else arg for arg in argv]


def endpoint_unit(endpoint):
    contents = stage.render_unit(endpoint, DESTINATION)
    contents = "\n".join(line for line in contents.splitlines()
                         if not line.startswith(("ExecStartPre=", "ExecStopPost=", "ExecStart=")))
    dependencies = f"[Unit]\nBindsTo={POOL_UNIT}\nAfter={POOL_UNIT}"
    return contents.replace("[Unit]", dependencies) + "\nExecStart=" + shlex.join(jumbo_argv(endpoint)) + "\n"


def pool_unit(host):
    return f"""[Unit]
Description=Reserve 2 MiB DPDK packet pages and set lab Ethernet MTU 4200
ConditionHost={stage.HOSTS[host]}

[Service]
Type=exec
User={stage.ACCOUNT}
Group={stage.ACCOUNT}
NoNewPrivileges=yes
RuntimeMaxSec=480
TimeoutStartSec=40
TimeoutStopSec=25
ExecStartPre=+/bin/bash {POOL_HELPER} prepare
ExecStart=/usr/bin/sleep infinity
ExecStopPost=+/bin/bash {POOL_HELPER} cleanup
"""


def installer(host, units, checksum):
    return f"""#!/bin/bash
set -euo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
[[ $EUID == 0 && $(hostname -s) == {stage.HOSTS[host]} ]]
cd -- "$(dirname -- "${{BASH_SOURCE[0]}}")"
active=$(systemctl list-units --state=running,activating,deactivating --no-legend --plain 'ocs-roce*.service' 'ocs-mrc*.service')
[[ -z $active ]] || {{ echo 'Wait for the current benchmark to finish.' >&2; exit 1; }}
[[ -x {DESTINATION}/roce_write ]] && id {stage.ACCOUNT} >/dev/null
stage=$(mktemp -d /run/ocs-roce-jumbo-install.XXXXXXXX)
trap 'rm -rf -- "$stage"' EXIT
units=({shlex.join(units)})
for file in "${{units[@]}}" pool.sh jumbo.sudoers SHA256SUMS; do
    install -o root -g root -m 0644 -- "$file" "$stage/$file"
done
printf '%s  %s\\n' '{checksum}' "$stage/SHA256SUMS" | sha256sum --check --strict --status
(cd "$stage" && sha256sum --check --strict SHA256SUMS)
visudo -cf "$stage/jumbo.sudoers"
systemd-analyze verify --man=no --generators=no --recursive-errors=no "${{units[@]/#/$stage/}}"
install -D -o root -g root -m 0755 -- "$stage/pool.sh" {POOL_HELPER}
for unit in "${{units[@]}}"; do
    install -o root -g root -m 0644 -- "$stage/$unit" "/etc/systemd/system/$unit"
done
systemctl daemon-reload
install -o root -g root -m 0440 -- "$stage/jumbo.sudoers" /etc/sudoers.d/ocs-roce-bw-same-cable-jumbo
echo '{host} same-cable jumbo benchmark installed.'
"""


def stage_packages():
    template = (OUTPUT / "pool.sh.in").read_text()
    for host, endpoints in ((LOCAL, (TX_LEFT, TX_RIGHT)), (REMOTE, (RX_LEFT, RX_RIGHT))):
        directory = OUTPUT / host
        directory.mkdir()
        units = (POOL_UNIT, *(endpoint.unit for endpoint in endpoints))
        (directory / POOL_UNIT).write_text(pool_unit(host))
        for endpoint in endpoints:
            (directory / endpoint.unit).write_text(endpoint_unit(endpoint))
        variables = {"HOSTNAME": stage.HOSTS[host],
                     "INTERFACES": " ".join(endpoint.link[2] for endpoint in endpoints),
                     "DEVICES": " ".join(endpoint.link[1] for endpoint in endpoints),
                     "RAILS": " ".join(str(endpoint.settings.rail) for endpoint in endpoints),
                     "PAGES": str(64 * len(endpoints))}
        helper = template
        for key, value in variables.items():
            helper = helper.replace(f"@{key}@", value)
        (directory / "pool.sh").write_text(helper)
        (directory / "jumbo.sudoers").write_text(stage.render_permissions(units))
        manifest = directory / "SHA256SUMS"
        manifest.write_text(stage.manifest_text(directory, (*units, "pool.sh", "jumbo.sudoers")))
        (directory / "install.sh").write_text(installer(host, units, stage.digest(manifest)))
        (directory / "install.sh").chmod(0o700)


def verify_access(commands, endpoint):
    for action in ("start", "stop"):
        commands.run(endpoint.host, "sudo", "-n", "-l", "/usr/bin/systemctl", action, endpoint.unit)
    commands.sudo_journals.add(endpoint)
    commands.journal(endpoint)


def verify_new_unit(commands, endpoint):
    props = commands.properties(endpoint, "LoadState", "ActiveState", "WorkingDirectory",
                                "Environment", "UnsetEnvironment", "ExecStart", "BindsTo", "After")
    bw.require(props.get("LoadState") == "loaded" and props.get("ActiveState") in ("inactive", "failed"),
               f"{endpoint.label}: unit unavailable or active")
    bw.require(props.get("WorkingDirectory") == str(DESTINATION), f"{endpoint.label}: wrong release")
    installed = re.findall(r"argv\[\]=(.*?) ;", props.get("ExecStart", ""))
    bw.require(len(installed) == 1 and shlex.split(installed[0]) == jumbo_argv(endpoint),
               f"{endpoint.label}: wrong arguments")
    env = sorted(f"{key}={value}" for key, value in
                 bw.unit_environment(endpoint, DESTINATION, DESTINATION / "lib").items())
    bw.require(sorted(shlex.split(props.get("Environment", ""))) == env and
               POOL_UNIT in props.get("BindsTo", "").split() and POOL_UNIT in props.get("After", "").split(),
               f"{endpoint.label}: wrong runtime environment or pool dependency")
    verify_access(commands, endpoint)


def link_state(commands, endpoint, mtu):
    host, pci, interface, wire_ip = endpoint.link
    sysfs = Path("/sys/class/net") / interface
    device = Path(commands.run(host, "readlink", "-f", sysfs / "device").strip()).name
    read = lambda name: int(commands.run(host, "cat", sysfs / name))
    mode = commands.run(host, "devlink", "dev", "param", "show", f"pci/{pci}", "name", "enable_roce")
    bw.require(device == pci and read("carrier") == 1 and read("speed") == 100_000
               and read("mtu") == mtu and "cmode driverinit value false" in mode,
               f"{endpoint.label}: expected raw Ethernet at 100 Gb/s and MTU {mtu}")
    return {"host": host, "device": pci, "interface": interface, "data_ip": wire_ip,
            "ethernet_mtu": mtu, "link_mbps": 100_000, "cpu_ids": list(endpoint.settings.cpus)}


def preflight(commands):
    digests = bw.app_digests(OUTPUT)
    for host in HOSTS:
        bw.require_idle(commands, host)
        directory = DESTINATION
        bw.verify_deployed_file(commands, host, directory)
        bw.verify_deployed_file(commands, host, POOL_HELPER)
        pool = Pool(host)
        path = Path("/etc/systemd/system") / POOL_UNIT
        expected = stage.digest(OUTPUT / host / POOL_UNIT)
        bw.verify_deployed_file(commands, host, path)
        bw.require(commands.run(host, "sha256sum", path).split()[0] == expected,
                   f"{host}: jumbo pool service checksum mismatch")
        expected = stage.digest(OUTPUT / host / "pool.sh")
        bw.require(commands.run(host, "sha256sum", POOL_HELPER).split()[0] == expected,
                   f"{host}: jumbo pool helper checksum mismatch")
        verify_access(commands, pool)
        for file, digest in digests.items():
            deployed = directory / file
            bw.verify_deployed_file(commands, host, deployed)
            bw.require(commands.run(host, "sha256sum", deployed).split()[0] == digest,
                       f"{host}: {deployed} differs from baseline")
        for name in ("nr_hugepages", "free_hugepages", "resv_hugepages", "surplus_hugepages"):
            bw.require(int(commands.run(host, "cat", SYSFS_POOL / name)) == 0,
                       f"{host}: another job is using the 2 MiB hugepage pool")
    for endpoint in NEW:
        verify_new_unit(commands, endpoint)
    for endpoints in PAIRS.values():
        for endpoint in endpoints:
            link_state(commands, endpoint, 1500)


def stop_pool(commands, pool, invocation, output):
    bw.stop_owned(commands, pool, invocation)
    count = int(commands.run(pool.host, "cat", SYSFS_POOL / "nr_hugepages"))
    rows = bw.invocation_messages(commands, pool, invocation)
    (output / f"{pool.host}-hugepage-pool.txt").write_text("\n".join(rows) + "\n")
    bw.require(count == 0 and "DPDK_HUGEPAGES restored=0 page_kib=2048" in rows,
               f"{pool.host}: temporary hugepage pool was not released")


def wait_result(commands, endpoint, invocation, deadline):
    while time.monotonic() < deadline:
        props = commands.properties(endpoint, "ActiveState", "InvocationID", "Result", "ExecMainStatus")
        if props.get("ActiveState") in bw.ACTIVE_STATES:
            bw.require(props.get("InvocationID") == invocation, f"{endpoint.label}: invocation changed")
        else:
            rows = bw.invocation_messages(commands, endpoint, invocation)
            bw.require(props.get("ActiveState") == "inactive" and props.get("Result") == "success"
                       and props.get("ExecMainStatus") == "0",
                       f"{endpoint.label}: unexpected service exit\n" + "\n".join(rows[-12:]))
            if bw.app_completion_marker(endpoint) in rows and any(row.startswith("BANDWIDTH ") for row in rows):
                return rows
        time.sleep(0.2)
    raise bw.CycleError(f"{endpoint.label}: timed out waiting for result")


def run_sample(commands, output, sample):
    invocations = {}
    try:
        for endpoint in (RX_LEFT, RX_RIGHT):
            invocations[endpoint] = bw.start(commands, endpoint)
        deadline = time.monotonic() + 60
        for endpoint in (RX_LEFT, RX_RIGHT):
            bw.wait_endpoint(commands, endpoint, invocations[endpoint], deadline, ready=True)
            bw.verify_loopback_listener(commands, endpoint.host, endpoint.settings.port)
        with socket.create_server((bw.LOOPBACK, bw.GATE_PORT)) as gate:
            for endpoint in (TX_LEFT, TX_RIGHT):
                invocations[endpoint] = bw.start(commands, endpoint)
            release = bw.release_senders(gate, [TX_LEFT.settings.port, TX_RIGHT.settings.port],
                                         time.monotonic() + 60)
        deadline = time.monotonic() + 90
        results = {}
        for name, endpoints in PAIRS.items():
            results[name] = {}
            for endpoint in endpoints:
                invocation = invocations[endpoint]
                rows = wait_result(commands, endpoint, invocation, deadline)
                (output / f"{name}-{sample}-{endpoint.role}.txt").write_text("\n".join(rows) + "\n")
                results[name][endpoint.role] = {"invocation": invocation, **bw.parse_result(endpoint, rows)}
        return bw.aggregate_result(results, release)
    finally:
        failed = sys.exc_info()[0] is not None
        errors = []
        for endpoint, invocation in reversed(tuple(invocations.items())):
            log = output / f"{endpoint.profile}-{sample}-{endpoint.role}-cleanup.txt"
            try:
                if failed:
                    rows = bw.invocation_messages(commands, endpoint, invocation)
                    log.write_text("\n".join(rows) + "\n")
            except (bw.CycleError, OSError, ValueError) as error:
                errors.append(str(error))
            try:
                bw.stop_owned(commands, endpoint, invocation)
            except bw.CycleError as error:
                errors.append(str(error))
        if errors:
            if not failed:
                raise bw.CycleError("\n".join(errors))
            print("\n".join(errors), file=sys.stderr)


def run(samples):
    bw.require(samples > 0 and socket.gethostname().split(".")[0] == stage.HOSTS[LOCAL],
               "Use a positive sample count and launch from Spark-04")
    with tempfile.TemporaryDirectory(prefix="roce-same-cable-jumbo-control-") as sockdir:
        commands = bw.Commands(sockdir)
        preflight(commands)
        output = Path(tempfile.mkdtemp(prefix="roce-same-cable-jumbo-results-"))
        print(f"Jumbo aggregate output {output}", flush=True)
        with ExitStack() as stack:
            stack.enter_context(bw.control_tunnels(commands, sockdir, MODES))
            for host in HOSTS:
                pool = Pool(host)
                invocation = bw.start(commands, pool)
                stack.callback(stop_pool, commands, pool, invocation, output)
                count = int(commands.run(host, "cat", SYSFS_POOL / "nr_hugepages"))
                bw.require(count == 128, f"{host}: expected 128 reserved 2 MiB pages")
            links = {name: {e.role: link_state(commands, e, 4200) for e in PAIRS[name]} for name in MODES}
            trials = []
            report = {"links": links, "pmtu": 4096, "packet_page_bytes": 2 << 20, "trials": trials,
                      "physical_qsfp_links": 1, "direction": "spark-04 to spark-02",
                      "packet_pool_pages_per_endpoint": 64, "qps_per_path": 16,
                      "workers_per_path": 4, "target_payload_bytes_per_path": 16 << 30,
                      "sha256": bw.app_digests(OUTPUT)}
            for sample in range(1, samples + 1):
                trial = run_sample(commands, output, sample)
                bw.require(trial["payload_bytes"] == 32 << 30 and trial["overlap_ns"] > 0,
                           "expected both transfers to overlap and complete 32 GiB")
                trials.append(trial)
                report["median_aggregate_payload_gbps"] = statistics.median(t["payload_gbps"] for t in trials)
                bw.save_report(output, report)
                rates = [r["tx"]["payload_gbps"] for r in trial["rails"].values()]
                print(f"Sample {sample}: {trial['payload_gbps']:.3f} Gb/s, {trial['overlap_fraction']:.2%} "
                      f"overlap, rates {rates}, {trial['tx_retries']} retries", flush=True)
        for endpoints in PAIRS.values():
            for endpoint in endpoints:
                link_state(commands, endpoint, 1500)
        report["restored_ethernet_mtu"] = 1500
        report["restored_hugepage_count"] = 0
        bw.save_report(output, report)
        print(f"Median aggregate: {report['median_aggregate_payload_gbps']:.3f} Gb/s", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("stage", "run"))
    parser.add_argument("--samples", type=int, default=3)
    args = parser.parse_args()
    try:
        if args.action == "stage":
            stage_packages()
        else:
            run(args.samples)
    except (bw.CycleError, OSError, ValueError, subprocess.SubprocessError) as error:
        sys.exit(str(error))
