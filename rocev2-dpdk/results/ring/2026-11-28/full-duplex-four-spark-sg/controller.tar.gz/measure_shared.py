from pathlib import Path
import json
import sys
run=Path(sys.argv[1])
rep=json.loads((run/'results.json').read_text())
for trial in rep['trials']:
    gate=trial['gate']; attempt=trial['attempt']; records={}
    def times(h,local):
        g=gate[h]
        offset=local-g['sender_gate_ns']+50_000_000
        return (g['controller_sent_ns']+offset,g['controller_received_ns']+offset)
    starts=[]; ends=[]
    for key,v in trial['links'].items():
        host=key.split('-to-')[0]; tx=v['tx']; start=int(tx['start_ns'])
        starts.append(times(host,start)[1]); ends.append(times(host,start+int(tx['elapsed_ns']))[0])
    shared=(max(starts),min(ends))
    win=[]; rates={}; diagnostics={}; packets=0
    for host in gate:
        data=[json.loads(l) for l in (run/f'{attempt}-{host}-gate.log').read_text().splitlines() if l.startswith('{')]
        for iface in ('enp1s0f0np0','enP2p1s0f1np1'):
            rows=[r for r in data if r['interface']==iface]
            assert len(rows)==5
            lo,hi=rows[0],rows[-1]
            start=times(host,lo['start_ns'])[0]; end=times(host,hi['end_ns'])[1]
            assert shared[0]<=start<end<=shared[1], (host,iface,shared,start,end)
            win.append((start,end))
            def rate(x,y):
                d=y['data_packets']-x['data_packets']
                elapsed=(y['start_ns']+y['end_ns']-x['start_ns']-x['end_ns'])/2
                return d*4096*8/elapsed
            idx=int(host[-2:])-1
            src=(idx+(-1 if iface.startswith('enp') else 1))%4
            key=f'spark-0{src+1}-to-{host}'
            rates[key]=rate(lo,hi)
            diagnostics[key]=[round(rate(x,y),3) for x,y in zip(rows,rows[1:])]
            packets+=hi['data_packets']-lo['data_packets']
    elapsed=max(e for _,e in win)-min(s for s,_ in win)
    print(attempt, 'synchronized RX rate',sum(rates.values()),'conservative floor',packets*32768/elapsed,'duration',elapsed/1e9)
    print('flow rates',rates,'subinterval rates',diagnostics)
    records=dict(large_rx_frame_payload_gbps=rates,ring_gbps=sum(rates.values()),maximum_read_envelope_ns=elapsed,ring_gbps_floor=packets*32768/elapsed,overlap_lower_bound_ns=shared[1]-shared[0],subinterval_gbps=diagnostics)
    (run/f'{attempt}-shared.json').write_text(json.dumps(records,indent=2)+'\n')
