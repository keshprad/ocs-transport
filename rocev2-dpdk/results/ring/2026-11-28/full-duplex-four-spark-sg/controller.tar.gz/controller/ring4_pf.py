"""Use the existing memfd receiver on spark-02's other right-QSFP function."""
from dataclasses import replace
import ring4 as base
from check_spark_peer_ring import Endpoint, bw, ring
class DirectReceiver(Endpoint):
    direct_receiver=True
    @property
    def unit(self): return 'ocs-roce-bw-app-memfd-gather-mtu-4200-multi-4-prefault.service'
    @property
    def pci(self): return '0000:01:00.1'
    @property
    def interface(self): return 'enp1s0f1np1'
    @property
    def cpus(self): return (5,6,7,8)
    @property
    def settings(self): return replace(super().settings,hugepages=False)
    def preflight(self,commands):
        props=commands.properties(self,'LoadState','ActiveState','ExecStart','WorkingDirectory')
        assert props['LoadState']=='loaded' and props['ActiveState'] in ('inactive','failed')
        dest='/opt/ocs-roce-app-bw/8c5058a'
        assert props['WorkingDirectory']==dest
        assert ' -l 5,6,7,8 --iova-mode=va --no-huge ' in props['ExecStart']
        assert ' rx 1048576 127.0.0.1 28938 10.61.0.1 4096 0000:01:00.1 --report-bw --tx-burst 16 --send-window 256 --writes 1024 --qps 16 --workers 4 --prefault-app' in props['ExecStart']
        for binary in ('roce_write','roce_app_write'):
            sums=commands.run(self.host,'sha256sum',dest+'/'+binary,base.peer.RELEASE/binary).splitlines()
            assert sums[0].split()[0]==sums[1].split()[0]
        bw.verify_service_access(commands,self)
        ring.verify_link(commands,self)
original=base.edges
def edges():
    paths=original()
    for i,(tx,rx) in enumerate(paths):
        if (tx.host,rx.host)==('spark-03','spark-02'):
            paths[i]=(tx,DirectReceiver(rx.host,rx.role,28938,'10.61.0.1'))
    return paths
if __name__=='__main__':
    base.edges=edges
    base.main()
