#!/usr/bin/env python3
"""Analyze the synchronized receive histograms even when a later WRITE fails."""
import json, statistics, sys
from pathlib import Path
def analyze(run):
    samples=[]
    for first in sorted(run.glob('*-spark-01-gate.log')):
        trial=int(first.name.split('-')[0])
        rates={}; port_rates={}; subintervals={}; duration=[]; read_spans=[]
        for h in range(1,5):
            f=run/f'{trial}-spark-0{h}-gate.log'
            rows=[json.loads(line) for line in f.read_text().splitlines() if line.startswith('{')]
            for iface in ('enp1s0f0np0','enP2p1s0f1np1'):
                data=[r for r in rows if r['interface']==iface]
                if len(data)!=5: break
                src=((h-1+(-1 if iface.startswith('enp') else 1))%4)+1
                link=f'spark-0{src}-to-spark-0{h}'
                def mid(r): return (r['start_ns']+r['end_ns'])/2
                def rate(a,b,key,bits): return (b[key]-a[key])*bits/(mid(b)-mid(a))
                rates[link]=rate(data[0],data[-1],'data_packets',32768)
                port_rates[link]=rate(data[0],data[-1],'rx_bytes_phy',8)
                subintervals[link]=[rate(a,b,'data_packets',32768) for a,b in zip(data,data[1:])]
                read_spans.extend(r['end_ns']-r['start_ns'] for r in data)
                duration.append((mid(data[-1])-mid(data[0]))/1e9)
        if len(rates)!=8: continue
        assert min(v for vs in subintervals.values() for v in vs)>0
        forward=[f'spark-0{i}-to-spark-0{i%4+1}' for i in range(1,5)]
        samples.append(dict(attempt=trial,data_payload_gbps=sum(rates.values()),physical_rx_octet_gbps=sum(port_rates.values()),forward_gbps=sum(rates[k] for k in forward),reverse_gbps=sum(v for k,v in rates.items() if k not in forward),links_gbps=rates,links_subinterval_gbps=subintervals,port_sample_duration_min_s=min(duration),port_sample_duration_max_s=max(duration),longest_read_ms=max(read_spans)/1e6))
    if not samples: return
    def med(key):return statistics.median(t[key] for t in samples)
    result=dict(trials=samples,median_ring_gbps=med('data_payload_gbps'),median_physical_rx_octet_gbps=med('physical_rx_octet_gbps'),median_forward_gbps=med('forward_gbps'),median_reverse_gbps=med('reverse_gbps'),median_links_gbps={k:statistics.median(t['links_gbps'][k] for t in samples) for k in samples[0]['links_gbps']})
    (run/'port-rates.json').write_text(json.dumps(result,indent=2)+'\n')
    print(run.name, 'median',result['median_ring_gbps'],'range',[round(t['data_payload_gbps'],3) for t in samples],'forward',result['median_forward_gbps'],'reverse',result['median_reverse_gbps'],'physical',result['median_physical_rx_octet_gbps'])
if __name__=='__main__':
    for path in sys.argv[1:]: analyze(Path(path))
