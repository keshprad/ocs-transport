"""Keep every PF and VF open until all eight data transfers have finished."""
from contextlib import contextmanager, ExitStack
from pathlib import Path
import socket
import struct
import subprocess
import threading
import time
import ring4 as base

def local_ports(i,tx,rx):
    controller=base.HOSTS[0]
    return (tx.port if tx.host==controller else 32740+i,
            rx.port if rx.host==controller else 32760+i)

@contextmanager
def tunnels(commands,sockets,paths):
    controller=base.HOSTS[0]
    sessions={h:[] for h in base.HOSTS[1:]}
    for i,(tx,rx) in enumerate(paths):
        ingress,egress=local_ports(i,tx,rx)
        if tx.host!=controller:
            sessions[tx.host] += ['-R',f'127.0.0.1:{tx.port}:127.0.0.1:{ingress}']
        if rx.host!=controller:
            sessions[rx.host] += ['-L',f'127.0.0.1:{egress}:127.0.0.1:{rx.port}']
    with ExitStack() as stack:
        for host,opts in sessions.items():
            ssh=['ssh','-S',str(Path(sockets)/(host+'.tunnel')),'-o','BatchMode=yes']
            subprocess.run([*ssh,'-fNT','-o','ConnectTimeout=6','-o','ControlMaster=yes',
                            '-o','ExitOnForwardFailure=yes',*opts,host],timeout=12,check=True)
            stack.callback(subprocess.run,[*ssh,'-O','exit',host],check=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=6)
        yield

def exact(sock,n):
    data=sock.recv(n,socket.MSG_WAITALL)
    if len(data)!=n: raise EOFError('Control connection closed')
    return data

def marker(src,dst,expected):
    value=exact(src,1)
    if value!=expected: raise ValueError(f'Unexpected control marker, expected {expected!r}')
    dst.sendall(value)

original=base.peer.run_sample

def sample(commands,output,number,paths):
    gate=threading.Barrier(len(paths))
    stopped=threading.Event()
    errors=[]
    log=[]
    def serve(listener,egress,label):
        try:
            while not stopped.is_set():
                try:
                    client,_=listener.accept()
                    break
                except TimeoutError:
                    continue
            else:
                return
            with client, socket.create_connection(('127.0.0.1',egress),timeout=8) as server:
                client.settimeout(110)
                server.settimeout(110)
                # The pinned benchmark exchanges its 46-byte offer, then three
                # 32-bit workload counts. Forward the exact bytes each supplied.
                for n in (46,4,4,4):
                    a=exact(client,n)
                    b=exact(server,n)
                    server.sendall(a)
                    client.sendall(b)
                marker(server,client,b'R')
                marker(client,server,b'R')
                done=exact(client,1)
                if done != b'D': raise ValueError('Expected sender transfer completion')
                log.append((label,'sender done',time.monotonic_ns()))
                gate.wait(timeout=26)
                # Only this post-data notification is delayed. Each receiver
                # still verifies its mapping and sends its own verification.
                server.sendall(done)
                marker(server,client,b'V')
                log.append((label,'receiver verified',time.monotonic_ns()))
        except Exception as e:
            errors.append(f'{label}: {e!r}')
            gate.abort()
    threads=[]
    with ExitStack() as stack:
        for i,(tx,rx) in enumerate(paths):
            ingress,egress=local_ports(i,tx,rx)
            sock=stack.enter_context(socket.create_server(('127.0.0.1',ingress)))
            sock.settimeout(.25)
            t=threading.Thread(target=serve,args=(sock,egress,base.ring.edge_name(tx,rx)),daemon=True)
            t.start()
            threads.append(t)
        try:
            result=original(commands,output,number,paths)
            if errors: raise RuntimeError(errors)
            return result
        finally:
            stopped.set()
            for t in threads: t.join(1)
            with (output/f'{number}-completion-barrier.txt').open('w') as f:
                for line in sorted(log,key=lambda x:x[2]): print(*line,file=f)
                for error in errors: print(error,file=f)
if __name__=='__main__':
    base.tunnels=tunnels
    base.peer.run_sample=sample
    base.main()
